#!/bin/bash
KEYSCD=$1
KEYTPC=$2

sudo cp nginx.conf nginx_new.conf
sudo sed -i "s/MYKEYSTREAMCODE/${KEYSCD}/g;" nginx_new.conf
sudo mv  nginx_new.conf res/nginx.conf

sudo cp matrix.conf matrix_new.conf
sudo sed -i "s/MYKEYSTREAMCODE/${KEYSCD}/g;" matrix_new.conf
sudo mv  matrix_new.conf res/matrix.conf

sudo unzip showlive.zip
sudo mv showlive/ res/
cd res/
sudo mv showlive/ "${KEYSCD}/"
cd ../
sudo cp index.html index_new.html
sed -i "s/MYKEYSTREAMCODE/${KEYSCD}/g; s/MYKEYSTREAMTOPIC/${KEYTPC}/g;" index_new.html
sudo mv  index_new.html "res/${KEYSCD}/index.html"
sudo mv res/matrix.conf /etc/nginx/conf.d/matrix.conf
sudo mv res/nginx.conf /etc/nginx/nginx.conf
sudo chmod 644 /etc/nginx/nginx.conf
sudo chmod 644 /etc/nginx/conf.d/matrix.conf
cd res/
sudo mv "${KEYSCD}/" "/tmp/"
chmod -R 777 "/tmp/${KEYSCD}/"
chmod -R 777 "/tmp/${KEYSCD}/hls/"
sudo systemctl restart nginx
